package com.shb.freshdelivery;

import android.app.*; import android.os.*; import android.content.*; import android.net.Uri;
import android.graphics.Color; import android.view.*; import android.widget.*; import java.util.*;

public class MainActivity extends Activity {
 LinearLayout content; ArrayList<Item> cart=new ArrayList<>(); ArrayList<Order> orders=new ArrayList<>();
 String[] products={"Goat / Sheep Mutton","Chicken","Chicken Breast","Mutton Curry Cut","Mutton Keema"};
 double[] prices={900,200,260,950,1000};
 android.content.SharedPreferences pref;

 static class Item {int p,q; Item(int p,int q){this.p=p;this.q=q;}}
 static class Order {String id,customer,address,items,status,payment;double total; Order(String i,String c,String a,String it,double t,String s,String p){id=i;customer=c;address=a;items=it;total=t;status=s;payment=p;}}

 @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
  content=findViewById(R.id.content); pref=getSharedPreferences("orders",0);
  findViewById(R.id.shopTab).setOnClickListener(v->showShop());
  findViewById(R.id.historyTab).setOnClickListener(v->showHistory());
  findViewById(R.id.adminTab).setOnClickListener(v->showAdmin());
  showShop();
 }
 TextView tv(String s,int z){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(Color.DKGRAY);t.setPadding(8,10,8,10);return t;}
 Button btn(String s){Button b=new Button(this);b.setText(s);return b;}
 void clear(){content.removeAllViews();}
 int qty(int p){for(Item x:cart)if(x.p==p)return x.q;return 0;}
 void add(int p,int d){for(Item x:cart)if(x.p==p){x.q=Math.max(0,x.q+d);if(x.q==0)cart.remove(x);showShop();return;} cart.add(new Item(p,1));showShop();}
 double subtotal(){double x=0;for(Item i:cart)x+=prices[i.p]*i.q;return x;}
 void showShop(){
  clear(); content.addView(tv("Fresh meat",25)); content.addView(tv("Choose products and build your cart.",14));
  for(int p=0;p<products.length;p++){ final int fp=p; LinearLayout row=new LinearLayout(this);row.setPadding(8,8,8,8);row.setBackgroundResource(R.drawable.card);
   LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);
   TextView a=tv(products[p],18);a.setTextColor(Color.rgb(11,84,39));info.addView(a);info.addView(tv("₹"+prices[p]+"/kg",14));
   row.addView(info,new LinearLayout.LayoutParams(0,90,1));
   Button minus=btn("−"), plus=btn("+"); TextView q=tv(""+qty(p),18);q.setGravity(Gravity.CENTER);
   row.addView(minus,new LinearLayout.LayoutParams(55,80));row.addView(q,new LinearLayout.LayoutParams(45,80));row.addView(plus,new LinearLayout.LayoutParams(55,80));
   minus.setOnClickListener(v->add(fp,-1));plus.setOnClickListener(v->add(fp,1));content.addView(row);content.addView(space());
  }
  content.addView(tv("CART • "+cart.size()+" products",20));
  content.addView(tv("Subtotal: ₹"+subtotal(),18));
  Button checkout=btn("VIEW CART & CHECKOUT"); checkout.setOnClickListener(v->checkout());content.addView(checkout);
 }
 View space(){Space s=new Space(this);s.setMinimumHeight(10);return s;}

 void checkout(){
  if(cart.isEmpty()){Toast.makeText(this,"Cart is empty",Toast.LENGTH_SHORT).show();return;}
  clear();content.addView(tv("Your cart",25));
  for(Item i:cart)content.addView(tv(products[i.p]+" × "+i.q+" kg  =  ₹"+(prices[i.p]*i.q),17));
  EditText name=new EditText(this);name.setHint("Customer name");content.addView(name);
  EditText phone=new EditText(this);phone.setHint("Mobile number");phone.setInputType(3);content.addView(phone);
  EditText address=new EditText(this);address.setHint("Delivery address");address.setMinLines(3);content.addView(address);
  Spinner payment=new Spinner(this);payment.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Cash on Delivery","UPI / Google Pay / PhonePe"}));content.addView(payment);
  Spinner distance=new Spinner(this);distance.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"0–1 km — ₹0","1–2 km — ₹30","2–5 km — ₹50"}));content.addView(distance);
  TextView total=tv("Total: ₹"+subtotal(),23);content.addView(total);
  distance.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){}public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){double f=pos==1?30:pos==2?50:0;total.setText("Total: ₹"+(subtotal()+f));}});
  Button pay=btn("PLACE ORDER & PAY");pay.setOnClickListener(v->place(name.getText().toString(),phone.getText().toString(),address.getText().toString(),payment.getSelectedItem().toString(),distance.getSelectedItemPosition()));content.addView(pay);
  Button back=btn("← Back to Shop");back.setOnClickListener(v->showShop());content.addView(back);
 }
 void place(String n,String ph,String ad,String pay,int dp){
  if(n.trim().isEmpty()||ph.trim().isEmpty()||ad.trim().isEmpty()){Toast.makeText(this,"Please fill all delivery details",Toast.LENGTH_SHORT).show();return;}
  double fee=dp==1?30:dp==2?50:0,total=subtotal()+fee;StringBuilder items=new StringBuilder();
  for(Item i:cart)items.append(products[i.p]).append(" × ").append(i.q).append("kg; ");
  String id="SHB"+System.currentTimeMillis();orders.add(new Order(id,n,ad,items.toString(),total,"Pending",pay));
  saveOrder(orders.get(orders.size()-1)); 
  if(pay.startsWith("UPI")){try{Intent in=new Intent(Intent.ACTION_VIEW, Uri.parse("upi://pay?pa=shbfresh@upi&pn=SHB%20Fresh%20Delivery&am="+total+"&cu=INR&tn="+Uri.encode(id)));startActivity(in);}catch(Exception e){Toast.makeText(this,"No UPI app found. Order saved.",Toast.LENGTH_LONG).show();}}
  String msg="SHB FRESH ORDER "+id+"\n"+items+"\nCustomer: "+n+"\nMobile: "+ph+"\nAddress: "+ad+"\nPayment: "+pay+"\nTOTAL: ₹"+total;
  try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/919901227765?text="+Uri.encode(msg))));}catch(Exception ignored){}
  cart.clear();showHistory();
 }
 void saveOrder(Order o){String old=pref.getString("list","");String line=o.id+"|"+o.customer+"|"+o.address+"|"+o.items+"|"+o.total+"|"+o.status+"|"+o.payment;pref.edit().putString("list",old+"#"+line).apply();}
 void load(){orders.clear();String s=pref.getString("list","");for(String x:s.split("#")){if(x.trim().isEmpty())continue;String[] a=x.split("\\|");if(a.length>=7)orders.add(new Order(a[0],a[1],a[2],a[3],Double.parseDouble(a[4]),a[5],a[6]));}}
 void showHistory(){load();clear();content.addView(tv("My Orders",25));if(orders.isEmpty()){content.addView(tv("No orders yet.",16));return;}Collections.reverse(orders);for(Order o:orders){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(14,14,14,14);c.setBackgroundResource(R.drawable.card);c.addView(tv(o.id+" • "+o.status,18));c.addView(tv(o.items,14));c.addView(tv(o.address,14));c.addView(tv("₹"+o.total+" • "+o.payment,16));content.addView(c);content.addView(space());}}
 void showAdmin(){
  load();clear();content.addView(tv("Admin / Order Management",25));content.addView(tv("Demo admin panel: orders are stored locally on this device.",14));
  if(orders.isEmpty()){content.addView(tv("No orders.",16));return;}
  for(Order o:orders){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(12,12,12,12);c.setBackgroundResource(R.drawable.card);c.addView(tv(o.id+" — ₹"+o.total,18));c.addView(tv(o.customer+"\n"+o.address+"\n"+o.items+"\nPayment: "+o.payment,14));
   Button b=btn("Mark Delivered");b.setOnClickListener(v->{o.status="Delivered";replace(o);showAdmin();});c.addView(b);content.addView(c);content.addView(space());}
 }
 void replace(Order o){StringBuilder s=new StringBuilder();for(Order x:orders)s.append("#").append(x.id).append("|").append(x.customer).append("|").append(x.address).append("|").append(x.items).append("|").append(x.total).append("|").append(x.status).append("|").append(x.payment);pref.edit().putString("list",s.toString()).apply();}
}